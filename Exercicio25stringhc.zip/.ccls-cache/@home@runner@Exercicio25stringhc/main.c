#include <stdio.h>
#include <string.h>



int main()
{
  char str[4][30];
  for(int i=0; i<4; i++)
    {
      printf("\n Nome: ");
      fflush(stdin);
      fgets(str[i],30,stdin);
    }
  
  

  
  if(strcmp(str[0],str[1])==-1)
   printf("\n %s, %s",str[0], str[1]);
   else if (strcmp(str[0], str[1])==1)
      printf("\n %s, %s",str[1], str[0]);
    else printf("\n São iguais\n");
  
  printf("\n %s tem %i caracteres", str[0], strlen(str[0]));
  printf("\n %s tem %i caracteres", str[1], strlen(str[1]));
  printf("\n %s tem %i caracteres", str[2], strlen(str[2]));
  
  
return 0;
}